package com.geektech.fragmenthomework3_2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.annotation.SuppressLint;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int count  = 0;
    private Button btnIncrement,btnDecrement;
    private TextView clickCount;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Fragment frag2 = new Fragment();
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        ft.add(R.id.conteiner, frag2);
        ft.commit();
        btnIncrement = findViewById(R.id.btn_increment);
        btnDecrement = findViewById(R.id.btn_decrement);
        clickCount = findViewById(R.id.zero_Tv);

        btnIncrement.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                count++;
                clickCount.setText(count+"Click!");
            }
        });
        btnDecrement.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                count--;
                clickCount.setText(count+"Click!");
            }
        });
    }
}